import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { Bar, Pie } from 'react-chartjs-2';
import './SchoolDetail.css';

function SchoolDetail() {
  const { schoolId } = useParams();
  const schoolIdNum = Number(schoolId);

  // 전체 학교 정보 가져오기
  const [schools, setSchools] = useState([]);
  // 각종 상세 정보 및 차트 데이터
  const [school, setSchool] = useState(null);
  const [tuitionByYear, setTuitionByYear] = useState({});
  const [scholarshipByYear, setScholarshipByYear] = useState({});
  const [stats, setStats] = useState([]); // 통계 항목들 (예: 원형/막대그래프용)
  const [reviews, setReviews] = useState([]);
  const [reviewInput, setReviewInput] = useState('');
  const [tab, setTab] = useState("news");

  // 모든 학교 fetch 후, 해당 id school 객체 세팅
  useEffect(() => {
    axios.get('/university/all')
      .then(res => {
        const arr = Array.isArray(res.data) ? res.data : [];
        setSchools(arr);
      })
      .catch(() => setSchools([]));
  }, []);

  // schoolMap/IdMap 만들고, 현재 school/코드 찾아내기
  const schoolMap = Object.fromEntries(
    schools.map(s => [Number(s.id), s])
  );
const currentSchool = schoolMap[schoolIdNum];
  // 상세 학교 정보
  useEffect(() => {
    if (!schoolIdNum || !school) return;
    axios.get(`/university/${schoolIdNum}`)
      .then(res => setSchool(res.data))
      .catch(() => setSchool(null));
  }, [schoolIdNum, schools]);

  // 등록금
  useEffect(() => {
    if (!schoolIdNum) return;
    axios.get(`/api/tuition/${schoolIdNum}`)
      .then(res => {
        const rows = Array.isArray(res.data) ? res.data : [];
        const dataMap = {};
        rows.forEach(row => { dataMap[row.year] = row.tuitionAmount; });
        setTuitionByYear(dataMap);
      })
      .catch(() => setTuitionByYear({}));
  }, [schoolIdNum]);

  // 장학금
  useEffect(() => {
    if (!schoolIdNum) return;
    axios.get(`/api/scholarship/${schoolIdNum}`)
      .then(res => {
        const rows = Array.isArray(res.data) ? res.data : [];
        const dataMap = {};
        rows.forEach(row => { dataMap[row.year] = row.scholarshipAmount; });
        setScholarshipByYear(dataMap);
      })
      .catch(() => setScholarshipByYear({}));
  }, [schoolIdNum]);

  // 통계항목
  useEffect(() => {
    if (!schoolIdNum) return;
    axios.get(`/api/statistics/${schoolIdNum}`)
      .then(res => setStats(Array.isArray(res.data) ? res.data : []))
      .catch(() => setStats([]));
  }, [schoolIdNum]);

  // 리뷰
  useEffect(() => {
    if (!schoolIdNum) return;
    axios.get(`/api/review/${schoolIdNum}`)
      .then(res => setReviews(Array.isArray(res.data) ? res.data : []))
      .catch(() => setReviews([]));
  }, [schoolIdNum]);

  // 리뷰 등록
  const submitReview = e => {
    e.preventDefault();
    if (!reviewInput.trim()) return;
    axios.post(`/api/review/${schoolIdNum}`, { content: reviewInput })
      .then(() => {
        setReviews([{ content: reviewInput, date: new Date().toISOString() }, ...reviews]);
        setReviewInput('');
      });
  };

  // 탭 정의
  const tabNames = {
    news: '학교정보',
    review: '졸업생 리뷰',
    tuition: '등록금',
    scholarship: '장학금'
  };

  // 바 차트 렌더링
  const renderBarChart = (title, dataMap) => {
    const labels = Object.keys(dataMap);
    const values = Object.values(dataMap);
    return (
      <div className="chart-box">
        <h3>{title}</h3>
        <Bar data={{
          labels,
          datasets: [{ label: title, data: values, backgroundColor: '#4CAF50' }]
        }} options={{ responsive: true, scales: { y: { beginAtZero: true } } }} />
      </div>
    );
  };

  // Pie 차트 예시 (통계 등)
  const renderPieChart = (title, stats) => {
    if (!stats || stats.length === 0) return <p>데이터 없음</p>;
    const labels = stats.map(s => s.label);
    const values = stats.map(s => s.value);
    return (
      <div className="chart-box">
        <h3>{title}</h3>
        <Pie data={{
          labels,
          datasets: [{ data: values }]
        }} />
      </div>
    );
  };

  // 리뷰탭
  const renderReviewTab = () => (
    <div className="school-info-container review-box">
      <h3>졸업생 리뷰 작성</h3>
      <form onSubmit={submitReview}>
        <input value={reviewInput}
          onChange={e => setReviewInput(e.target.value)}
          placeholder="리뷰를 입력하세요" maxLength={300} />
        <button type="submit">등록</button>
      </form>
      <h4>리뷰 목록</h4>
      <ul>
        {reviews.length === 0 && <li style={{ color: "#777" }}>아직 등록된 리뷰가 없습니다.</li>}
        {reviews.map((r, idx) => (
          <li key={idx}>
            <div>{r.content}</div>
            <div style={{ color: "#aaa", fontSize: 12 }}>
              {r.date ? new Date(r.date).toLocaleString() : ""}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );

  if (!school) return <div>학교 정보를 불러오는 중입니다...</div>;

  return (
    <div className="school-detail-root">
      <div className="tab-row">
        {Object.entries(tabNames).map(([key, label]) => (
          <span key={key}
            className={tab === key ? "tab-selected" : ""}
            onClick={() => setTab(key)}>
            {label}
          </span>
        ))}
      </div>

      {/* 학교 정보 */}
      {tab === "news" && (
        <div className="school-info-container">
          <div>
            <img src={school.imageUrl} alt={school.name} className="school-img" />
          </div>
          <div className="school-text">
            <ul>
              <li><strong>학교명:</strong> {school.name}</li>
              <li><strong>위치:</strong> {school.location}</li>
              <li><strong>설립유형:</strong> {school.type}</li>
              <li><strong>설명:</strong> {school.description}</li>
              <li><strong>홈페이지:</strong> <a href={school.website} target="_blank" rel="noreferrer">{school.website}</a></li>
            </ul>
          </div>
          <div className="chart-column">
            {renderPieChart("통계 항목", stats)}
          </div>
        </div>
      )}

      {/* 등록금 탭 */}
      {tab === "tuition" && renderBarChart("연도별 등록금", tuitionByYear)}

      {/* 장학금 탭 */}
      {tab === "scholarship" && renderBarChart("연도별 장학금", scholarshipByYear)}

      {/* 리뷰 탭 */}
      {tab === "review" && renderReviewTab()}
    </div>
  );
}

export default SchoolDetail;
