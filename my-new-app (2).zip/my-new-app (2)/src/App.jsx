import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import EmotionService from './services/EmotionService';
import Header from './Header';
import Footer from './footer';
import Home from './Home';
import Signup from './Signup';
import Login from './Login';
import Location from './Location';
import News from './News';
import Ranking from './Ranking';
import All3 from './All3';
import All4 from './All4';
import KakaoLogin from './KakaoLogin';
import KakaoRedirectHandler from './kakaoRedirectHandler';
import SchoolDetail from './SchoolDetail'; // ✅ SchoolDetail도 import

function App() {
  useEffect(() => {
    EmotionService.getEmotions()
      .then(response => console.log(response.data))
      .catch(error => console.error(error));
  }, []);

  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/location" element={<Location />} />
        <Route path="/news" element={<News />} />
        <Route path="/ranking" element={<Ranking />} />
        <Route path="/all3" element={<All3 />} />
        <Route path="/all4" element={<All4 />} />
        <Route path="/kakaologin" element={<KakaoLogin />} />
        <Route path="/footer" element={<Footer />} />
        <Route path="/oauth/kakao" element={<KakaoRedirectHandler />} />
        {/* ✅ 추가된 학교 상세페이지 경로 */}
        <Route path="/school/:schoolId" element={<SchoolDetail />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
