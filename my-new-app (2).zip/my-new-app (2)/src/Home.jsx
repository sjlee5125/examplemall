import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './App.css';

function Home() {
  const navigate = useNavigate();
  const [collegeData, setCollegeData] = useState([]);
  const [universityData, setUniversityData] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8080/university/type/전문")
      .then(res => res.json())
      .then(data => setCollegeData(data))
      .catch(console.error);
  }, []);

  useEffect(() => {
    fetch("http://localhost:8080/university/type/일반")
      .then(res => res.json())
      .then(data => setUniversityData(data))
      .catch(console.error);
  }, []);

  return (
    <div>
      <h2>전문대학교</h2>
      <div style={{ display: "flex", gap: "24px" }}>
        {collegeData.map(item => (
          <div key={item.id}
               style={{ width: 240, cursor: "pointer", background: "#f4e1c9", borderRadius: 20, padding: 20 }}
               onClick={() => navigate(`/school/${item.id}`)}>
            <img src={item.imageUrl} alt={item.name} style={{ width: 200, height: 180, borderRadius: 20 }} />
            <div><b>{item.name}</b></div>
            <div>{item.location}</div>
          </div>
        ))}
      </div>
      <h2 style={{ marginTop: 40 }}>4년제 대학교</h2>
      <div style={{ display: "flex", gap: "24px" }}>
        {universityData.map(item => (
          <div key={item.id}
               style={{ width: 240, cursor: "pointer", background: "#f4e1c9", borderRadius: 20, padding: 20 }}
               onClick={() => navigate(`/school/${item.id}`)}>
            <img src={item.imageUrl} alt={item.name} style={{ width: 200, height: 180, borderRadius: 20 }} />
            <div><b>{item.name}</b></div>
            <div>{item.location}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
export default Home;
