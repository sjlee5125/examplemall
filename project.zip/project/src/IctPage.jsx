import React from 'react';

function IctPage() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>ICT폴리텍대학</h1>
      <p>ICT폴리텍대학에 대한 상세 설명 페이지입니다.</p>
    </div>
  );
}

export default IctPage;